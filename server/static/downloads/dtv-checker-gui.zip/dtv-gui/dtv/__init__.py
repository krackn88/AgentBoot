"""DirectTV account checker package."""
